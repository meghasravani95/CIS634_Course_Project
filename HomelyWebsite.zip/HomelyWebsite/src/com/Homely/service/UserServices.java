package com.Homely.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.Homely.dao.userDAO;
import com.Homely.entity.users;

public class UserServices {
	
	private EntityManagerFactory entityManagerFactory;
	private EntityManager entityManager;
	private userDAO usersDAO;
	
	
	
	
	public UserServices() {
		
	entityManagerFactory= Persistence.createEntityManagerFactory("HomelyWebsite");
	System.out.println("executed");
	entityManager =entityManagerFactory.createEntityManager();
	 usersDAO =new userDAO(entityManager);
	}



	public List<users> listUser()
	{
		List<users> listusers= usersDAO.listAll();
		
		return listusers;
		
	}

}
