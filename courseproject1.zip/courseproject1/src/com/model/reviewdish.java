package com.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class reviewdish implements Serializable {
	
	private static final long serialVersionUID = 1L;
		@Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private int id;

		@Column(nullable = false, length = 45)
		private String chefname;
		
		@Column(nullable = false, length = 45)
		private String customername;
		
		@Column(nullable = false, length=1)
		private String rating;
		
		@Column(nullable = false, length = 200)
		private String reviewdescription;

		public String getChefname() {
			return chefname;
		}

		public void setChefname(String chefname) {
			this.chefname = chefname;
		}

		public String getCustomername() {
			return customername;
		}

		public void setCustomername(String customername) {
			this.customername = customername;
		}

		public String getRating() {
			return rating;
		}

		public void setRating(String rating) {
			this.rating = rating;
		}

		public String getReviewdescription() {
			return reviewdescription;
		}

		public void setReviewdescription(String reviewdescription) {
			this.reviewdescription = reviewdescription;
		}


}
