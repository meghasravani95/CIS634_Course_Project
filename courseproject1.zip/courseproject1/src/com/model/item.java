package com.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import com.model.dish;

public class item implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int itemid;
	
	@Column(nullable=false)
	private int quantity;
	
	private dish Dish;
	
	
	public item() {
	}

	public item(dish Dish, int quantity) {
		this.Dish = Dish;
		this.quantity = quantity;
	}

	public dish getDish() {
		return Dish;
	}

	public void setDish(dish Dish) {
		this.Dish = Dish;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	

}
