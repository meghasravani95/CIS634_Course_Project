package com.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class dish implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int dishid;


	@Column(length=45,nullable=false)
	private String dishname;

	@Column(nullable=false)
	private float dishprice;
	
	@Column(nullable=false)
	private byte[] dishimage;
	
	@Column(nullable=false,length=45)
	private String chefname;

	public int getDishid() {
		return dishid;
	}

	public void setDishid(int dishid) {
		this.dishid = dishid;
	}

	public String getDishname() {
		return dishname;
	}

	public void setDishname(String dishname) {
		this.dishname = dishname;
	}

	public float getDishprice() {
		return dishprice;
	}

	public void setDishprice(float dishprice) {
		this.dishprice = dishprice;
	}

	public byte[] getDishimage() {
		return dishimage;
	}

	public void setDishimage(byte[] dishimage) {
		this.dishimage = dishimage;
	}

	public String getChefname() {
		return chefname;
	}

	public void setChefname(String chefname) {
		this.chefname = chefname;
	}

	
	
}
