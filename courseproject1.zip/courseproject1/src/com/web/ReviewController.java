package com.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.dao.reviewdishDao;
import com.model.reviewdish;

@WebServlet("/review")
public class ReviewController extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private reviewdishDao ReviewdishDao;
	
	 public void init() {
	        ReviewdishDao = new reviewdishDao();
	    }

	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	    throws ServletException, IOException {
	        register(request, response);
	    }

	    protected void doGet(HttpServletRequest request, HttpServletResponse response)
	    throws ServletException, IOException {
	        response.sendRedirect("review.jsp");
	    }

	    private void register(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
	        String chefname = request.getParameter("chefname");
	        String customername = request.getParameter("customername");
	        String rating = request.getParameter("rating"); 
	        String reviewdescription = request.getParameter("reviewdescription");
	        
	        reviewdish review= new reviewdish();
	        
	      
	        review.setChefname(chefname);
	        review.setCustomername(customername);
	        review.setRating(rating);
	        review.setReviewdescription(reviewdescription);
	        

	        ReviewdishDao.saveReview(review);

	        RequestDispatcher dispatcher = request.getRequestDispatcher("reviewsuccess.jsp");
	        dispatcher.forward(request, response);
	    }

}
