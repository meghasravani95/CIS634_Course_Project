
package com.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.customerDao;

@WebServlet("/login")
public class LoginController extends HttpServlet{
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private customerDao loginDao;

	    public void init() {
	        loginDao = new customerDao();
	    }

	    protected void doGet(HttpServletRequest request, HttpServletResponse response)
	    throws ServletException, IOException {
	        response.sendRedirect("login.jsp");
	    }

	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	    throws ServletException, IOException {
	        try {
	            authenticate(request, response);
	        } catch (Exception e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	    }

	    private void authenticate(HttpServletRequest request, HttpServletResponse response)
	    throws Exception {
	        String email = request.getParameter("email");
	        String password = request.getParameter("password");
	        
	        //System.out.println(email+password);

	        if (loginDao.validate(email, password)) {
	            RequestDispatcher dispatcher = request.getRequestDispatcher("sample.html");
	            dispatcher.forward(request, response);
	        } else {
	            throw new Exception("Login not successful..");
	        }
	    }

}
