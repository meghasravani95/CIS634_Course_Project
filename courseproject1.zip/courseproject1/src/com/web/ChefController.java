package com.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.chefDao;
import com.model.chef;

@WebServlet("/register")
public class ChefController extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private chefDao ChefDao;

    public void init() {
        ChefDao = new chefDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        register(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.sendRedirect("register.jsp");
    }

    private void register(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String mobile = request.getParameter("mobile"); 
        String email = request.getParameter("email");
        String cuisinetype = request.getParameter("cuisinetype");

       chef chef = new chef();
        chef.setFirstName(firstName);
       chef.setLastName(lastName);
       chef.setMobile(mobile);
       chef.setEmail(email);
       chef.setCuisinetype(cuisinetype);

        ChefDao.saveChef(chef);

        RequestDispatcher dispatcher = request.getRequestDispatcher("registersuccess.jsp");
        dispatcher.forward(request, response);
    }

}
