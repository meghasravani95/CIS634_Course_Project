package com.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.customerDao;
import com.model.customer;

@WebServlet("/registercustomer")
public class CustomerController extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private customerDao CustomerDao;

    public void init() {
        CustomerDao = new customerDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        register(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.sendRedirect("registercustomer.jsp");
    }

    private void register(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String telnum = request.getParameter("telnum"); 
        String email = request.getParameter("email");
        String password = request.getParameter("password");

       customer customer = new customer();
        customer.setFirstName(firstName);
        customer.setLastName(lastName);
        customer.setTelnum(telnum);
        customer.setEmail(email);
        customer.setPassword(password);
        
        CustomerDao.saveCustomer(customer);

        RequestDispatcher dispatcher = request.getRequestDispatcher("registersuccesscustomer.jsp");
        dispatcher.forward(request, response);
    }

}
