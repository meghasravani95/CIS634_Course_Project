package com.dao;

import com.model.dish;

public class dishDao {

	public Object findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public dish find(String parameter) {
		// TODO Auto-generated method stub
		return null;
	}


}
