package courseproject1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class cheftest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
